'use client'

import { useState } from 'react'
import { useStore } from '@/store'
import { X, Key, Eye, EyeOff, Trash2, Download, Upload, Monitor, Code, Brain, Shield, Palette } from 'lucide-react'

interface SettingsModalProps {
  onClose: () => void
}

type Tab = 'api' | 'appearance' | 'app' | 'privacy' | 'data'

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      style={{
        width: 40, height: 22, borderRadius: 11, border: 'none', cursor: 'pointer',
        background: checked ? 'var(--accent)' : 'var(--bg-tertiary)',
        position: 'relative', transition: 'background 0.2s', flexShrink: 0,
      }}
    >
      <div style={{
        position: 'absolute', top: 3, left: checked ? 21 : 3,
        width: 16, height: 16, borderRadius: '50%', background: 'white',
        transition: 'left 0.2s', boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
      }} />
    </button>
  )
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '1rem', padding: '0.65rem 0', borderBottom: '1px solid var(--border)' }}>
      <div>
        <div style={{ fontSize: '0.875rem', fontWeight: 500 }}>{label}</div>
        {hint && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.1rem' }}>{hint}</div>}
      </div>
      {children}
    </div>
  )
}

export function SettingsModal({ onClose }: SettingsModalProps) {
  const {
    apiKey, setApiKey,
    defaultModel, setDefaultModel,
    noLogMode, setNoLogMode,
    makeAppEnabled, setMakeAppEnabled,
    conversations,
    appPages,
  } = useStore()

  const [tab, setTab] = useState<Tab>('api')
  const [showKey, setShowKey] = useState(false)
  const [keyInput, setKeyInput] = useState(apiKey)

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'api', label: 'API', icon: <Key size={14} /> },
    { id: 'appearance', label: 'Theme', icon: <Palette size={14} /> },
    { id: 'app', label: 'Make App', icon: <Monitor size={14} /> },
    { id: 'privacy', label: 'Privacy', icon: <Shield size={14} /> },
    { id: 'data', label: 'Data', icon: <Download size={14} /> },
  ]

  const exportData = () => {
    const data = JSON.stringify({ conversations, appPages }, null, 2)
    const blob = new Blob([data], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'kii-chat-export.json'; a.click()
    URL.revokeObjectURL(url)
  }

  const clearAll = () => {
    if (confirm('Delete all conversations? This cannot be undone.')) {
      useStore.setState({ conversations: [], currentConversationId: null })
    }
  }

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 100,
      background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '1rem',
    }}
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div style={{
        background: 'var(--bg-secondary)', border: '1px solid var(--border)',
        borderRadius: 16, width: '100%', maxWidth: 540,
        maxHeight: '85vh', display: 'flex', flexDirection: 'column',
        boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
      }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)' }}>
          <span style={{ fontWeight: 700, fontSize: '1rem' }}>Settings</span>
          <button onClick={onClose} style={{ padding: '0.3rem', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', borderRadius: 6 }}>
            <X size={18} />
          </button>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', padding: '0 0.75rem', gap: '0.1rem', overflowX: 'auto' }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              display: 'flex', alignItems: 'center', gap: '0.35rem',
              padding: '0.6rem 0.75rem', border: 'none', background: 'transparent',
              color: tab === t.id ? 'var(--accent)' : 'var(--text-muted)',
              borderBottom: `2px solid ${tab === t.id ? 'var(--accent)' : 'transparent'}`,
              cursor: 'pointer', fontSize: '0.82rem', fontWeight: tab === t.id ? 600 : 400,
              whiteSpace: 'nowrap',
            }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '1rem 1.25rem' }}>
          {/* API */}
          {tab === 'api' && (
            <div>
              <div style={{ marginBottom: '1rem' }}>
                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.35rem' }}>
                  OpenRouter API Key
                </label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showKey ? 'text' : 'password'}
                    value={keyInput}
                    onChange={e => setKeyInput(e.target.value)}
                    onBlur={() => setApiKey(keyInput)}
                    placeholder="sk-or-..."
                    style={{
                      width: '100%', padding: '0.55rem 2.5rem 0.55rem 0.75rem',
                      background: 'var(--bg-input)', border: '1px solid var(--border)',
                      borderRadius: 8, color: 'var(--text-primary)', fontSize: '0.875rem',
                      outline: 'none', fontFamily: 'monospace',
                    }}
                  />
                  <button
                    onClick={() => setShowKey(!showKey)}
                    style={{ position: 'absolute', right: '0.5rem', top: '50%', transform: 'translateY(-50%)', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer' }}
                  >
                    {showKey ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </div>
                <p style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.35rem' }}>
                  Get a key at <a href="https://openrouter.ai/keys" target="_blank" rel="noopener" style={{ color: 'var(--accent)' }}>openrouter.ai/keys</a>. Stored locally only.
                </p>
              </div>

              <div>
                <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.35rem' }}>
                  Default Model
                </label>
                <select
                  value={defaultModel}
                  onChange={e => setDefaultModel(e.target.value)}
                  style={{
                    width: '100%', padding: '0.55rem 0.75rem',
                    background: 'var(--bg-input)', border: '1px solid var(--border)',
                    borderRadius: 8, color: 'var(--text-primary)', fontSize: '0.875rem', outline: 'none',
                  }}
                >
                  <optgroup label="Anthropic">
                    <option value="anthropic/claude-opus-4.6">Claude Opus 4.6</option>
                    <option value="anthropic/claude-sonnet-4-5">Claude Sonnet 4.5</option>
                    <option value="anthropic/claude-haiku-4-5">Claude Haiku 4.5</option>
                  </optgroup>
                  <optgroup label="Google">
                    <option value="google/gemini-2.5-pro">Gemini 2.5 Pro</option>
                    <option value="google/gemini-2.5-flash">Gemini 2.5 Flash</option>
                  </optgroup>
                  <optgroup label="OpenAI">
                    <option value="openai/gpt-4o">GPT-4o</option>
                    <option value="openai/gpt-4o-mini">GPT-4o Mini</option>
                    <option value="openai/o3">o3</option>
                  </optgroup>
                  <optgroup label="Meta">
                    <option value="meta-llama/llama-4-scout">Llama 4 Scout</option>
                    <option value="meta-llama/llama-3.3-70b-instruct">Llama 3.3 70B</option>
                  </optgroup>
                  <optgroup label="Mistral">
                    <option value="mistralai/mistral-large-2411">Mistral Large</option>
                    <option value="mistralai/mistral-small-3.1-24b-instruct">Mistral Small</option>
                  </optgroup>
                  <optgroup label="DeepSeek">
                    <option value="deepseek/deepseek-r1">DeepSeek R1</option>
                    <option value="deepseek/deepseek-chat-v3-5">DeepSeek V3</option>
                  </optgroup>
                </select>
              </div>
            </div>
          )}

          {/* Theme */}
          {tab === 'appearance' && (
            <div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-secondary)', marginBottom: '1rem' }}>
                Kii Chat uses a clean dark theme designed for readability and focus.
              </p>
              <div style={{
                padding: '1rem', border: '1px solid var(--accent)', borderRadius: 10,
                background: 'var(--accent-bg)', fontSize: '0.85rem', color: 'var(--text-secondary)',
              }}>
                <div style={{ fontWeight: 600, color: 'var(--accent)', marginBottom: '0.35rem' }}>Dark (Active)</div>
                Deep charcoal background with purple accents. Optimized for long coding sessions.
              </div>
            </div>
          )}

          {/* Make App */}
          {tab === 'app' && (
            <div>
              <Row
                label="Enable Make App"
                hint="Show an App button next to the send button. Models can build and preview React apps in real time."
              >
                <Toggle checked={makeAppEnabled} onChange={setMakeAppEnabled} />
              </Row>

              {makeAppEnabled && (
                <div style={{ marginTop: '1rem', padding: '0.9rem', background: 'var(--bg-tertiary)', borderRadius: 10, fontSize: '0.85rem', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
                  <div style={{ fontWeight: 600, color: 'var(--text-primary)', marginBottom: '0.5rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <Monitor size={15} style={{ color: 'var(--accent)' }} /> How it works
                  </div>
                  <ul style={{ paddingLeft: '1.2rem', margin: 0 }}>
                    <li>Ask any model to build you a React app or UI component.</li>
                    <li>When code appears, click <strong style={{ color: 'var(--accent)' }}>▶ App</strong> on the code block to preview it.</li>
                    <li>On mobile: tap <strong style={{ color: 'var(--accent)' }}>App</strong> near the send button to open the preview.</li>
                    <li>Use ← → arrows to browse apps from different models.</li>
                    <li>Each model gets its own separate app page.</li>
                  </ul>
                </div>
              )}

              {makeAppEnabled && Object.keys(appPages).length > 0 && (
                <div style={{ marginTop: '0.75rem' }}>
                  <div style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--text-secondary)', marginBottom: '0.4rem' }}>
                    Active apps ({Object.keys(appPages).length})
                  </div>
                  {Object.keys(appPages).map(modelId => (
                    <div key={modelId} style={{
                      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      padding: '0.4rem 0.75rem', background: 'var(--bg-tertiary)', borderRadius: 7, marginBottom: '0.3rem',
                    }}>
                      <span style={{ fontSize: '0.82rem', color: 'var(--accent)' }}>
                        {modelId.split('/').pop()}
                      </span>
                      <button
                        onClick={() => {
                          const { [modelId]: _, ...rest } = useStore.getState().appPages
                          useStore.setState({ appPages: rest })
                        }}
                        style={{ border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '0.75rem' }}
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Privacy */}
          {tab === 'privacy' && (
            <div>
              <Row label="No-Log Mode" hint="Tells models not to use your messages for training (provider-dependent).">
                <Toggle checked={noLogMode} onChange={setNoLogMode} />
              </Row>
            </div>
          )}

          {/* Data */}
          {tab === 'data' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.65rem' }}>
              <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                {conversations.length} conversation{conversations.length !== 1 ? 's' : ''} stored locally.
              </div>
              <button
                onClick={exportData}
                style={{
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  padding: '0.6rem 0.9rem', borderRadius: 8, border: '1px solid var(--border)',
                  background: 'var(--bg-tertiary)', color: 'var(--text-secondary)',
                  cursor: 'pointer', fontSize: '0.875rem',
                }}
              >
                <Download size={15} /> Export all data (JSON)
              </button>
              <button
                onClick={clearAll}
                style={{
                  display: 'flex', alignItems: 'center', gap: '0.5rem',
                  padding: '0.6rem 0.9rem', borderRadius: 8, border: '1px solid rgba(248,113,113,0.3)',
                  background: 'rgba(248,113,113,0.08)', color: '#f87171',
                  cursor: 'pointer', fontSize: '0.875rem',
                }}
              >
                <Trash2 size={15} /> Clear all conversations
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
