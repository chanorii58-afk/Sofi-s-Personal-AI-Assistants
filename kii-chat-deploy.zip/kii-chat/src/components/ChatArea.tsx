'use client'

import { useEffect, useRef, useState } from 'react'
import { useStore } from '@/store'
import { ChatMessage } from '@/components/ChatMessage'
import { ChatInput } from '@/components/ChatInput'
import { AppPanel } from '@/components/AppPanel'
import { ModelSelector } from '@/components/ModelSelector'
import { Menu, ChevronDown, Layers } from 'lucide-react'

interface ChatAreaProps {
  onSidebarToggle: () => void
}

export function ChatArea({ onSidebarToggle }: ChatAreaProps) {
  const { currentConversation, isStreaming, makeAppEnabled, appPages } = useStore()
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [showApp, setShowApp] = useState(false)
  const [mobileAppView, setMobileAppView] = useState(false)

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [currentConversation?.messages?.length, isStreaming])

  const hasApps = Object.keys(appPages).length > 0
  const messages = currentConversation?.messages || []

  // Mobile: show app page
  if (mobileAppView && makeAppEnabled) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', overflow: 'hidden' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          padding: '0.65rem 1rem', borderBottom: '1px solid var(--border)',
          background: 'var(--bg-secondary)', flexShrink: 0,
        }}>
          <button
            onClick={() => setMobileAppView(false)}
            style={{ padding: '0.3rem', border: 'none', background: 'transparent', color: 'var(--text-secondary)', cursor: 'pointer', borderRadius: 6 }}
          >
            ← Back
          </button>
          <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>App Preview</span>
        </div>
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <AppPanel onClose={() => setMobileAppView(false)} />
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', flex: 1 }}>
      {/* Chat column */}
      <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden', minWidth: 0 }}>
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.5rem',
          padding: '0.65rem 1rem', borderBottom: '1px solid var(--border)',
          background: 'var(--bg-secondary)', flexShrink: 0,
        }}>
          <button
            onClick={onSidebarToggle}
            style={{ padding: '0.35rem', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', borderRadius: 6 }}
          >
            <Menu size={18} />
          </button>

          <div style={{ flex: 1 }}>
            <ModelSelector />
          </div>

          {/* Desktop app toggle */}
          {makeAppEnabled && (
            <button
              onClick={() => setShowApp(!showApp)}
              style={{
                display: 'none', // Only on md+ (hidden on mobile)
                alignItems: 'center', gap: '0.35rem',
                padding: '0.35rem 0.65rem', borderRadius: 7,
                border: '1px solid var(--border)',
                background: showApp ? 'var(--accent-bg)' : 'transparent',
                color: showApp ? 'var(--accent)' : 'var(--text-muted)',
                cursor: 'pointer', fontSize: '0.8rem',
              }}
              className="!md:flex hidden"
            >
              <Layers size={14} />
              {hasApps && <span style={{
                width: 6, height: 6, borderRadius: '50%',
                background: 'var(--success)', display: 'inline-block',
              }} />}
              Apps
            </button>
          )}
        </div>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 0 1rem 0' }}>
          {messages.length === 0 ? (
            <div style={{
              height: '100%', display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              color: 'var(--text-muted)', gap: '0.5rem', padding: '2rem',
            }}>
              <div style={{
                width: 48, height: 48, borderRadius: '50%', background: 'var(--accent)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '1.3rem', color: 'white', fontWeight: 700, marginBottom: '0.5rem',
              }}>K</div>
              <div style={{ fontWeight: 600, fontSize: '1.1rem', color: 'var(--text-secondary)' }}>
                How can I help you?
              </div>
              <div style={{ fontSize: '0.85rem', textAlign: 'center', maxWidth: 340 }}>
                Start a conversation. Press <kbd style={{
                  padding: '0.1rem 0.35rem', borderRadius: 4,
                  border: '1px solid var(--border)', background: 'var(--bg-tertiary)',
                  fontSize: '0.78rem',
                }}>Enter</kbd> for a new line, send with the button or <kbd style={{
                  padding: '0.1rem 0.35rem', borderRadius: 4,
                  border: '1px solid var(--border)', background: 'var(--bg-tertiary)',
                  fontSize: '0.78rem',
                }}>Ctrl+Enter</kbd>.
              </div>
            </div>
          ) : (
            <div style={{ maxWidth: 800, margin: '0 auto', padding: '0.5rem 0' }}>
              {messages.map(msg => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
              {isStreaming && (
                <div style={{ padding: '0.75rem 1rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
                  <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, color: 'white', fontWeight: 700, fontSize: '0.75rem' }}>AI</div>
                  <div style={{ display: 'flex', gap: '0.3rem', alignItems: 'center', paddingTop: '0.5rem' }}>
                    {[0, 1, 2].map(i => (
                      <div key={i} style={{
                        width: 7, height: 7, borderRadius: '50%',
                        background: 'var(--text-muted)',
                        animation: `pulse 1.2s ${i * 0.2}s ease-in-out infinite`,
                      }} />
                    ))}
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input */}
        <ChatInput onOpenApp={() => {
          // On mobile: navigate to app view
          if (window.innerWidth < 768) {
            setMobileAppView(true)
          } else {
            setShowApp(!showApp)
          }
        }} />
      </div>

      {/* Desktop App panel */}
      {showApp && makeAppEnabled && (
        <div style={{ width: '45%', minWidth: 320, maxWidth: 600, flexShrink: 0, overflow: 'hidden' }} className="hidden md:block">
          <AppPanel onClose={() => setShowApp(false)} />
        </div>
      )}
    </div>
  )
}
