'use client'

import { useState } from 'react'
import { useStore } from '@/store'
import { Plus, MessageSquare, Trash2, ChevronLeft, Settings, Search } from 'lucide-react'
import { v4 as uuidv4 } from 'uuid'

interface SidebarProps {
  isOpen: boolean
  onToggle: () => void
}

export function Sidebar({ isOpen, onToggle }: SidebarProps) {
  const {
    conversations, currentConversationId, defaultModel,
    personas, currentPersona, setShowSettings,
  } = useStore()
  const [search, setSearch] = useState('')

  const createNew = () => {
    const id = uuidv4()
    const persona = personas.find(p => p.id === currentPersona) || personas[0]
    const conv = { id, title: 'New chat', messages: [], createdAt: Date.now(), updatedAt: Date.now(), persona: persona.id, model: defaultModel }
    useStore.setState(s => ({ conversations: [conv, ...s.conversations], currentConversationId: id }))
  }

  const del = (e: React.MouseEvent, id: string) => {
    e.stopPropagation()
    useStore.setState(s => {
      const rem = s.conversations.filter(c => c.id !== id)
      return { conversations: rem, currentConversationId: s.currentConversationId === id ? (rem[0]?.id ?? null) : s.currentConversationId }
    })
  }

  const filtered = conversations.filter(c =>
    c.title.toLowerCase().includes(search.toLowerCase())
  )
  const now = Date.now()
  const groups = [
    { label: 'Today', items: filtered.filter(c => now - c.updatedAt < 86400000) },
    { label: 'This week', items: filtered.filter(c => now - c.updatedAt >= 86400000 && now - c.updatedAt < 604800000) },
    { label: 'Older', items: filtered.filter(c => now - c.updatedAt >= 604800000) },
  ]

  return (
    <>
      {isOpen && <div className="md:hidden fixed inset-0 z-30 bg-black/50" onClick={onToggle} />}
      <aside style={{
        width: isOpen ? 260 : 0, minWidth: isOpen ? 260 : 0,
        overflow: 'hidden', transition: 'width 0.2s, min-width 0.2s',
        background: 'var(--bg-secondary)', borderRight: '1px solid var(--border)',
        height: '100vh', display: 'flex', flexDirection: 'column', flexShrink: 0,
        position: 'relative', zIndex: 10,
      }}>
        <div style={{ width: 260, display: 'flex', flexDirection: 'column', height: '100%' }}>
          {/* Header */}
          <div style={{ display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.85rem 0.75rem', borderBottom:'1px solid var(--border)' }}>
            <div style={{ width:28, height:28, borderRadius:'50%', background:'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
              <span style={{ fontSize:'0.8rem', color:'white', fontWeight:700 }}>K</span>
            </div>
            <span style={{ fontWeight:600, fontSize:'0.95rem', flex:1 }}>Kii Chat</span>
            <button onClick={onToggle} style={{ padding:'0.3rem', borderRadius:'6px', border:'none', background:'transparent', color:'var(--text-muted)', cursor:'pointer' }}>
              <ChevronLeft size={16} />
            </button>
          </div>
          {/* New Chat */}
          <div style={{ padding:'0.6rem 0.75rem' }}>
            <button onClick={createNew} style={{
              width:'100%', display:'flex', alignItems:'center', gap:'0.5rem',
              padding:'0.5rem 0.75rem', borderRadius:'8px', border:'1px solid var(--border)',
              background:'var(--accent-bg)', color:'var(--accent)', cursor:'pointer',
              fontSize:'0.875rem', fontWeight:500,
            }}>
              <Plus size={15} /> New chat
            </button>
          </div>
          {/* Search */}
          {conversations.length > 3 && (
            <div style={{ padding:'0 0.75rem 0.5rem' }}>
              <div style={{ position:'relative' }}>
                <Search size={13} style={{ position:'absolute', left:'0.5rem', top:'50%', transform:'translateY(-50%)', color:'var(--text-muted)' }} />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search chats" style={{
                  width:'100%', padding:'0.4rem 0.5rem 0.4rem 1.75rem',
                  background:'var(--bg-tertiary)', border:'1px solid var(--border)', borderRadius:'6px',
                  color:'var(--text-primary)', fontSize:'0.8rem', outline:'none',
                }} />
              </div>
            </div>
          )}
          {/* List */}
          <div style={{ flex:1, overflowY:'auto', paddingBottom:'0.5rem' }}>
            {filtered.length === 0 ? (
              <div style={{ padding:'2rem 1rem', textAlign:'center', color:'var(--text-muted)', fontSize:'0.85rem' }}>
                {search ? 'No results' : 'No conversations yet'}
              </div>
            ) : groups.map(({ label, items }) => items.length > 0 && (
              <div key={label} className="mb-2">
                <div style={{ fontSize:'0.7rem', color:'var(--text-muted)', padding:'0.4rem 0.75rem 0.2rem', fontWeight:600, textTransform:'uppercase', letterSpacing:'0.05em' }}>{label}</div>
                {items.map(conv => (
                  <div key={conv.id} onClick={() => useStore.setState({ currentConversationId: conv.id })}
                    className="group"
                    style={{
                      display:'flex', alignItems:'center', gap:'0.5rem', padding:'0.45rem 0.75rem',
                      borderRadius:'6px', cursor:'pointer', margin:'1px 0.35rem',
                      background: conv.id === currentConversationId ? 'var(--bg-tertiary)' : 'transparent',
                      transition:'background 0.12s',
                    }}
                    onMouseEnter={e => { if(conv.id!==currentConversationId)(e.currentTarget as HTMLDivElement).style.background='var(--bg-secondary)' }}
                    onMouseLeave={e => { if(conv.id!==currentConversationId)(e.currentTarget as HTMLDivElement).style.background='transparent' }}
                  >
                    <MessageSquare size={14} style={{ color:'var(--text-muted)', flexShrink:0 }} />
                    <span style={{ flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontSize:'0.875rem', color: conv.id===currentConversationId?'var(--text-primary)':'var(--text-secondary)' }}>
                      {conv.title || 'New chat'}
                    </span>
                    <button onClick={e => del(e, conv.id)} style={{
                      opacity:0, padding:'0.1rem', borderRadius:'4px', border:'none',
                      background:'transparent', cursor:'pointer', color:'var(--text-muted)',
                    }}
                      className="group-hover:!opacity-100 hover:!text-red-400"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
              </div>
            ))}
          </div>
          {/* Bottom */}
          <div style={{ borderTop:'1px solid var(--border)', padding:'0.6rem 0.75rem' }}>
            <button onClick={() => setShowSettings(true)} style={{
              width:'100%', display:'flex', alignItems:'center', gap:'0.6rem',
              padding:'0.5rem 0.6rem', borderRadius:'8px', border:'none',
              background:'transparent', color:'var(--text-secondary)', cursor:'pointer', fontSize:'0.875rem',
            }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background='var(--bg-tertiary)'; (e.currentTarget as HTMLButtonElement).style.color='var(--text-primary)' }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background='transparent'; (e.currentTarget as HTMLButtonElement).style.color='var(--text-secondary)' }}
            >
              <Settings size={15} /> Settings
            </button>
          </div>
        </div>
      </aside>
    </>
  )
}
