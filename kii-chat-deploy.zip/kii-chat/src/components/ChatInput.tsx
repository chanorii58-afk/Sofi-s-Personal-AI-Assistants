'use client'

import { useState, useRef, useEffect, KeyboardEvent, ChangeEvent } from 'react'
import { useStore } from '@/store'
import { sendMessage, sendMessageViaProxy } from '@/lib/openrouter'
import { Send, Loader2, StopCircle, Paperclip, X, Monitor } from 'lucide-react'

interface AttachmentFile {
  name: string
  type: string
  dataUrl: string
  size: number
}

export function ChatInput({ onOpenApp }: { onOpenApp?: () => void }) {
  const {
    currentConversationId, currentConversation, addMessage,
    updateMessageContent, apiKey, isStreaming, setIsStreaming,
    personas, noLogMode, makeAppEnabled,
    ultraplinianApiUrl, ultraplinianApiKey,
    memoriesEnabled, memories, customSystemPrompt, useCustomSystemPrompt,
  } = useStore()

  const [input, setInput] = useState('')
  const [attachments, setAttachments] = useState<AttachmentFile[]>([])
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const abortRef = useRef<AbortController | null>(null)

  const proxyMode = !apiKey && !!ultraplinianApiUrl && !!ultraplinianApiKey

  // Auto-resize
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`
    }
  }, [input])

  const handleFiles = async (files: FileList) => {
    const newAtts: AttachmentFile[] = []
    for (const file of Array.from(files)) {
      const dataUrl = await new Promise<string>(resolve => {
        const reader = new FileReader()
        reader.onload = e => resolve(e.target?.result as string || '')
        reader.readAsDataURL(file)
      })
      newAtts.push({ name: file.name, type: file.type, dataUrl, size: file.size })
    }
    setAttachments(prev => [...prev, ...newAtts])
  }

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files)
      e.target.value = ''
    }
  }

  const removeAttachment = (idx: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== idx))
  }

  // Enter = newline (no send). Send button or Shift+Enter (actually let's make Shift+Enter also a newline, send only via button)
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    // Enter always = newline; send only via button
    // But allow Ctrl+Enter or Cmd+Enter to send for power users
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleSubmit()
    }
    // Plain Enter = insert newline (default behavior for textarea)
  }

  const handleSubmit = async () => {
    if ((!input.trim() && attachments.length === 0) || !currentConversationId || isStreaming) return
    if (!apiKey && !proxyMode) return

    const text = input.trim()
    setInput('')
    setIsStreaming(true)

    const persona = personas.find(p => p.id === currentConversation?.persona) || personas[0]
    const model = currentConversation?.model || 'anthropic/claude-opus-4.6'

    // Build content for API (text + image attachments)
    const imageAtts = attachments.filter(a => a.type.startsWith('image/'))
    const fileAtts = attachments.filter(a => !a.type.startsWith('image/'))

    let userContent: any = text
    if (imageAtts.length > 0) {
      const parts: any[] = []
      if (text) parts.push({ type: 'text', text })
      imageAtts.forEach(a => {
        const base64 = a.dataUrl.split(',')[1]
        parts.push({ type: 'image_url', image_url: { url: `data:${a.type};base64,${base64}` } })
      })
      if (fileAtts.length > 0) {
        fileAtts.forEach(f => parts.push({ type: 'text', text: `[File: ${f.name}]` }))
      }
      userContent = parts
    } else if (fileAtts.length > 0) {
      userContent = text + (fileAtts.length > 0 ? '\n' + fileAtts.map(f => `[Attached: ${f.name}]`).join('\n') : '')
    }

    // Store message with attachments for display
    addMessage(currentConversationId, {
      role: 'user',
      content: text || '[files attached]',
      ...(attachments.length > 0 ? { attachments: attachments.map(a => ({ name: a.name, type: a.type, dataUrl: a.dataUrl })) } : {}),
    } as any)

    setAttachments([])

    // Build memory context
    const activeMemories = memoriesEnabled ? memories.filter(m => m.active) : []
    let memCtx = ''
    if (activeMemories.length > 0) {
      memCtx = '\n\n<user_memory>\n' +
        activeMemories.map(m => `- ${m.content}`).join('\n') +
        '\n</user_memory>\n'
    }
    const basePrompt = useCustomSystemPrompt ? customSystemPrompt : (persona.systemPrompt || persona.coreDirective || '')
    const systemPrompt = basePrompt + memCtx

    const messages = [
      ...(systemPrompt ? [{ role: 'system' as const, content: systemPrompt }] : []),
      ...((currentConversation?.messages || []).map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }))),
      { role: 'user' as const, content: userContent },
    ]

    try {
      abortRef.current = new AbortController()
      const response = proxyMode
        ? await sendMessageViaProxy({ messages, model, apiBaseUrl: ultraplinianApiUrl, godmodeApiKey: ultraplinianApiKey, signal: abortRef.current.signal, stm_modules: [] })
        : await sendMessage({ messages, model, apiKey, noLog: noLogMode, signal: abortRef.current.signal })

      addMessage(currentConversationId, { role: 'assistant', content: response, model, persona: persona.id })
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        addMessage(currentConversationId, {
          role: 'assistant',
          content: `**Error:** ${err.message || 'Failed to get response. Check your API key in Settings.'}`,
          model, persona: persona.id,
        })
      } else {
        addMessage(currentConversationId, { role: 'assistant', content: '_[Stopped]_', model, persona: persona.id })
      }
    } finally {
      setIsStreaming(false)
      abortRef.current = null
    }
  }

  const canSend = (input.trim() || attachments.length > 0) && (!!apiKey || proxyMode) && !isStreaming

  return (
    <div style={{
      borderTop: '1px solid var(--border)',
      background: 'var(--bg-primary)',
      padding: '0.75rem 1rem',
    }}
      className="input-safe"
    >
      <div style={{ maxWidth: 800, margin: '0 auto' }}>
        {/* Attachment previews */}
        {attachments.length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.4rem', marginBottom: '0.5rem' }}>
            {attachments.map((att, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: '0.4rem',
                padding: '0.3rem 0.5rem', background: 'var(--bg-tertiary)',
                border: '1px solid var(--border)', borderRadius: 8,
                fontSize: '0.78rem', color: 'var(--text-secondary)',
              }}>
                {att.type.startsWith('image/') ? (
                  <img src={att.dataUrl} alt={att.name} style={{ width: 28, height: 28, objectFit: 'cover', borderRadius: 4 }} />
                ) : (
                  <span>📄</span>
                )}
                <span style={{ maxWidth: 100, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{att.name}</span>
                <button
                  onClick={() => removeAttachment(i)}
                  style={{ border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', padding: 0, lineHeight: 1 }}
                >
                  <X size={12} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Input row */}
        <div style={{
          display: 'flex', alignItems: 'flex-end', gap: '0.5rem',
          background: 'var(--bg-input)', border: '1px solid var(--border)',
          borderRadius: 12, padding: '0.5rem 0.5rem 0.5rem 0.75rem',
          transition: 'border-color 0.15s',
        }}
          onFocus={() => {}}
        >
          {/* Attach button */}
          <button
            onClick={() => fileInputRef.current?.click()}
            title="Attach files or images"
            style={{
              flexShrink: 0, padding: '0.4rem', borderRadius: 7, border: 'none',
              background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer',
              display: 'flex', alignItems: 'center',
              transition: 'color 0.12s',
            }}
            onMouseEnter={e => (e.currentTarget.style.color = 'var(--text-primary)')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
          >
            <Paperclip size={17} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*,.pdf,.txt,.js,.ts,.py,.json,.md,.csv,.lua"
            style={{ display: 'none' }}
            onChange={handleFileChange}
          />

          {/* Textarea */}
          <textarea
            ref={textareaRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={(apiKey || proxyMode) ? 'Message Kii Chat… (Enter for new line)' : 'Set your API key in Settings first'}
            disabled={(!apiKey && !proxyMode) || isStreaming}
            rows={1}
            style={{
              flex: 1, background: 'transparent', border: 'none', color: 'var(--text-primary)',
              fontSize: '0.9rem', lineHeight: 1.5, minHeight: 36, maxHeight: 200,
              padding: '0.35rem 0', fontFamily: 'inherit', outline: 'none',
              resize: 'none',
            }}
          />

          {/* App button (mobile: redirects to app view) */}
          {makeAppEnabled && (
            <button
              onClick={onOpenApp}
              title="View apps"
              style={{
                flexShrink: 0, padding: '0.4rem 0.55rem', borderRadius: 7,
                border: '1px solid var(--border)', background: 'var(--accent-bg)',
                color: 'var(--accent)', cursor: 'pointer', fontSize: '0.72rem',
                display: 'flex', alignItems: 'center', gap: '0.2rem',
                transition: 'all 0.12s',
              }}
              onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-bg-hover)' }}
              onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = 'var(--accent-bg)' }}
            >
              <Monitor size={14} />
              <span className="hidden sm:inline">App</span>
            </button>
          )}

          {/* Send / Stop */}
          {isStreaming ? (
            <button
              onClick={() => abortRef.current?.abort()}
              style={{
                flexShrink: 0, padding: '0.4rem', borderRadius: 8, border: 'none',
                background: 'rgba(248,113,113,0.15)', color: '#f87171', cursor: 'pointer',
              }}
            >
              <StopCircle size={18} />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={!canSend}
              style={{
                flexShrink: 0, padding: '0.4rem 0.65rem', borderRadius: 8, border: 'none',
                background: canSend ? 'var(--accent)' : 'var(--bg-tertiary)',
                color: canSend ? 'white' : 'var(--text-muted)',
                cursor: canSend ? 'pointer' : 'not-allowed',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.12s',
              }}
            >
              {isStreaming ? <Loader2 size={17} className="animate-spin" /> : <Send size={17} />}
            </button>
          )}
        </div>

        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.35rem', textAlign: 'center' }}>
          Ctrl+Enter to send · Enter for new line
        </div>
      </div>
    </div>
  )
}
