'use client'

import { useState, useCallback } from 'react'
import { Message, useStore } from '@/store'
import { Copy, Check, Download, User, ChevronLeft, ChevronRight } from 'lucide-react'
import ReactMarkdown from 'react-markdown'
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter'
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism'

interface ChatMessageProps {
  message: Message
}

function getExtension(lang: string): string {
  const map: Record<string, string> = {
    javascript: 'js', typescript: 'ts', tsx: 'tsx', jsx: 'jsx',
    python: 'py', lua: 'lua', rust: 'rs', go: 'go', java: 'java',
    css: 'css', html: 'html', json: 'json', bash: 'sh', shell: 'sh',
    sql: 'sql', cpp: 'cpp', c: 'c', ruby: 'rb', php: 'php',
    swift: 'swift', kotlin: 'kt', yaml: 'yaml', toml: 'toml',
    markdown: 'md', xml: 'xml',
  }
  return map[lang?.toLowerCase()] || 'txt'
}

function getModelSlug(model?: string): string {
  if (!model) return 'model'
  return model.split('/').pop()?.replace(/[^a-zA-Z0-9_-]/g, '-') || 'model'
}

export function ChatMessage({ message }: ChatMessageProps) {
  const { personas, currentConversation, makeAppEnabled, setAppPage } = useStore()
  const [copied, setCopied] = useState(false)
  const [raceIndex, setRaceIndex] = useState(0)

  const raceResponses = message.raceResponses
  const hasRace = raceResponses && raceResponses.length > 1
  const activeResponse = hasRace ? raceResponses[raceIndex] : null
  const displayContent = activeResponse ? activeResponse.content : message.content
  const displayModel = activeResponse ? activeResponse.model : message.model

  const isUser = message.role === 'user'
  const persona = !isUser
    ? personas.find(p => p.id === (message.persona || currentConversation?.persona)) || personas[0]
    : null

  const handleCopy = async () => {
    await navigator.clipboard.writeText(displayContent)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const downloadCode = useCallback((code: string, lang: string) => {
    const slug = getModelSlug(displayModel)
    const ext = getExtension(lang)
    const filename = `${slug}.${ext}`
    const blob = new Blob([code], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = filename; a.click()
    URL.revokeObjectURL(url)
  }, [displayModel])

  const sendToApp = useCallback((code: string, lang: string) => {
    if (!makeAppEnabled) return
    const model = displayModel || 'default'
    setAppPage(model, code)
  }, [makeAppEnabled, displayModel, setAppPage])

  if (isUser) {
    return (
      <div className="animate-fade-in" style={{ display: 'flex', justifyContent: 'flex-end', padding: '0.75rem 1rem 0.75rem 3rem' }}>
        <div style={{
          maxWidth: '75%',
          background: 'var(--user-bubble)',
          border: '1px solid var(--border)',
          borderRadius: '18px 18px 4px 18px',
          padding: '0.65rem 1rem',
          fontSize: '0.9rem',
          lineHeight: 1.6,
          color: 'var(--text-primary)',
          whiteSpace: 'pre-wrap',
          wordBreak: 'break-word',
        }}>
          {/* Attached files */}
          {(message as any).attachments?.length > 0 && (
            <div style={{ marginBottom: '0.5rem', display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
              {(message as any).attachments.map((att: any, i: number) => (
                <div key={i} className="file-preview">
                  {att.type?.startsWith('image/') ? (
                    <img src={att.dataUrl} alt={att.name} className="file-preview-img" />
                  ) : (
                    <span>📄 {att.name}</span>
                  )}
                </div>
              ))}
            </div>
          )}
          {message.content}
        </div>
      </div>
    )
  }

  return (
    <div className="animate-fade-in" style={{ padding: '0.75rem 1rem', display: 'flex', gap: '0.75rem', alignItems: 'flex-start' }}>
      {/* Avatar */}
      <div style={{
        width: 32, height: 32, borderRadius: '50%',
        background: 'var(--accent)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0, fontSize: '0.75rem', color: 'white', fontWeight: 700,
      }}>
        {persona?.emoji || 'AI'}
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Model label */}
        {displayModel && (
          <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '0.35rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <span style={{ fontWeight: 600, color: 'var(--accent)' }}>{getModelSlug(displayModel)}</span>
            {hasRace && (
              <span style={{ color: 'var(--text-muted)' }}>· {raceIndex + 1}/{raceResponses.length}</span>
            )}
          </div>
        )}

        {/* Content */}
        <div className="prose" style={{ fontSize: '0.9rem', lineHeight: 1.7 }}>
          {displayContent === '' ? (
            <span style={{ color: 'var(--text-muted)' }} className="animate-pulse-slow">●●●</span>
          ) : (
            <ReactMarkdown
              components={{
                code({ node, className, children, ...props }: any) {
                  const match = /language-(\w+)/.exec(className || '')
                  const lang = match?.[1] || ''
                  const code = String(children).replace(/\n$/, '')
                  const isBlock = code.includes('\n') || lang

                  if (!isBlock) return <code {...props} className={className}>{children}</code>

                  const isReact = ['jsx', 'tsx', 'react'].includes(lang.toLowerCase()) ||
                    code.includes('import React') || code.includes('export default') || code.includes('useState')

                  return (
                    <div className="code-block-wrapper" style={{ borderRadius: 8, overflow: 'hidden', margin: '0.5rem 0', border: '1px solid var(--border)' }}>
                      {/* Code header */}
                      <div style={{
                        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                        padding: '0.35rem 0.75rem',
                        background: '#1e1e2e',
                        borderBottom: '1px solid var(--border)',
                      }}>
                        <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', fontFamily: 'monospace' }}>
                          {lang || 'code'} · {getModelSlug(displayModel)}.{getExtension(lang)}
                        </span>
                        <div style={{ display: 'flex', gap: '0.35rem' }}>
                          {isReact && makeAppEnabled && (
                            <button
                              onClick={() => sendToApp(code, lang)}
                              style={{
                                display: 'flex', alignItems: 'center', gap: '0.25rem',
                                padding: '0.15rem 0.5rem', borderRadius: 4,
                                border: '1px solid var(--accent)', background: 'var(--accent-bg)',
                                color: 'var(--accent)', cursor: 'pointer', fontSize: '0.7rem',
                              }}
                            >
                              ▶ App
                            </button>
                          )}
                          <button
                            onClick={() => downloadCode(code, lang)}
                            title={`Download as ${getModelSlug(displayModel)}.${getExtension(lang)}`}
                            style={{
                              display: 'flex', alignItems: 'center', gap: '0.25rem',
                              padding: '0.15rem 0.5rem', borderRadius: 4,
                              border: '1px solid var(--border)', background: 'var(--bg-tertiary)',
                              color: 'var(--text-secondary)', cursor: 'pointer', fontSize: '0.7rem',
                            }}
                          >
                            <Download size={11} /> Save
                          </button>
                        </div>
                      </div>
                      <SyntaxHighlighter
                        style={oneDark as any}
                        language={lang}
                        PreTag="div"
                        customStyle={{ margin: 0, borderRadius: 0, background: '#1a1a2e', fontSize: '0.82em' }}
                      >
                        {code}
                      </SyntaxHighlighter>
                    </div>
                  )
                },
              }}
            >
              {displayContent}
            </ReactMarkdown>
          )}
        </div>

        {/* Footer actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.5rem' }}>
          <button
            onClick={handleCopy}
            style={{
              display: 'flex', alignItems: 'center', gap: '0.3rem',
              padding: '0.25rem 0.5rem', borderRadius: 5, border: 'none',
              background: 'transparent', color: 'var(--text-muted)',
              cursor: 'pointer', fontSize: '0.75rem',
              transition: 'color 0.12s',
            }}
            onMouseEnter={e => (e.currentTarget.style.color = 'var(--text-primary)')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--text-muted)')}
          >
            {copied ? <Check size={13} /> : <Copy size={13} />}
            {copied ? 'Copied' : 'Copy'}
          </button>

          {/* Race navigator */}
          {hasRace && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginLeft: 'auto' }}>
              <button
                onClick={() => setRaceIndex(i => Math.max(0, i - 1))}
                disabled={raceIndex === 0}
                style={{
                  padding: '0.2rem', borderRadius: 4, border: 'none',
                  background: raceIndex === 0 ? 'transparent' : 'var(--bg-tertiary)',
                  color: raceIndex === 0 ? 'var(--text-muted)' : 'var(--text-secondary)',
                  cursor: raceIndex === 0 ? 'not-allowed' : 'pointer',
                }}
              >
                <ChevronLeft size={14} />
              </button>
              <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                {raceIndex + 1} / {raceResponses.length}
              </span>
              <button
                onClick={() => setRaceIndex(i => Math.min(raceResponses.length - 1, i + 1))}
                disabled={raceIndex === raceResponses.length - 1}
                style={{
                  padding: '0.2rem', borderRadius: 4, border: 'none',
                  background: raceIndex === raceResponses.length - 1 ? 'transparent' : 'var(--bg-tertiary)',
                  color: raceIndex === raceResponses.length - 1 ? 'var(--text-muted)' : 'var(--text-secondary)',
                  cursor: raceIndex === raceResponses.length - 1 ? 'not-allowed' : 'pointer',
                }}
              >
                <ChevronRight size={14} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
