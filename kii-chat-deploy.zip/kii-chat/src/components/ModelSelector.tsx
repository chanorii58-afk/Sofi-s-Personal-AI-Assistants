'use client'

import { useStore } from '@/store'
import { ChevronDown } from 'lucide-react'

const MODELS = [
  { id: 'anthropic/claude-opus-4.6', name: 'Claude Opus 4.6', provider: 'Anthropic' },
  { id: 'anthropic/claude-sonnet-4-5', name: 'Claude Sonnet 4.5', provider: 'Anthropic' },
  { id: 'anthropic/claude-haiku-4-5', name: 'Claude Haiku 4.5', provider: 'Anthropic' },
  { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro', provider: 'Google' },
  { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash', provider: 'Google' },
  { id: 'openai/gpt-4o', name: 'GPT-4o', provider: 'OpenAI' },
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', provider: 'OpenAI' },
  { id: 'openai/o3', name: 'o3', provider: 'OpenAI' },
  { id: 'meta-llama/llama-4-scout', name: 'Llama 4 Scout', provider: 'Meta' },
  { id: 'meta-llama/llama-3.3-70b-instruct', name: 'Llama 3.3 70B', provider: 'Meta' },
  { id: 'mistralai/mistral-large-2411', name: 'Mistral Large', provider: 'Mistral' },
  { id: 'deepseek/deepseek-r1', name: 'DeepSeek R1', provider: 'DeepSeek' },
  { id: 'deepseek/deepseek-chat-v3-5', name: 'DeepSeek V3.5', provider: 'DeepSeek' },
  { id: 'x-ai/grok-3', name: 'Grok 3', provider: 'xAI' },
  { id: 'qwen/qwen-2.5-coder-32b-instruct', name: 'Qwen 2.5 Coder', provider: 'Alibaba' },
]

export function ModelSelector() {
  const { currentConversation } = useStore()
  const currentModel = currentConversation?.model || 'anthropic/claude-opus-4.6'
  const modelInfo = MODELS.find(m => m.id === currentModel)

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const modelId = e.target.value
    if (currentConversation) {
      useStore.setState(s => ({
        conversations: s.conversations.map(c =>
          c.id === currentConversation.id ? { ...c, model: modelId } : c
        )
      }))
    }
  }

  return (
    <div style={{ position: 'relative', display: 'inline-flex', alignItems: 'center' }}>
      <select
        value={currentModel}
        onChange={handleChange}
        style={{
          appearance: 'none', background: 'transparent',
          border: '1px solid var(--border)', borderRadius: 8,
          color: 'var(--text-primary)', fontSize: '0.82rem',
          padding: '0.3rem 1.75rem 0.3rem 0.6rem',
          cursor: 'pointer', outline: 'none',
        }}
      >
        {MODELS.map(m => (
          <option key={m.id} value={m.id} style={{ background: '#1a1a1a' }}>
            {m.name} · {m.provider}
          </option>
        ))}
      </select>
      <ChevronDown size={13} style={{ position: 'absolute', right: '0.4rem', pointerEvents: 'none', color: 'var(--text-muted)' }} />
    </div>
  )
}
