'use client'

import { useStore } from '@/store'
import { Key, Zap, Monitor, Download } from 'lucide-react'
import { v4 as uuidv4 } from 'uuid'

export function WelcomeScreen({ onOpenSettings }: { onOpenSettings: () => void }) {
  const { apiKey, ultraplinianApiUrl, ultraplinianApiKey, defaultModel, personas, currentPersona } = useStore()
  const hasKey = !!apiKey || (!!ultraplinianApiUrl && !!ultraplinianApiKey)

  const startChat = () => {
    const id = uuidv4()
    const persona = personas.find(p => p.id === currentPersona) || personas[0]
    useStore.setState(s => ({
      conversations: [{ id, title: 'New chat', messages: [], createdAt: Date.now(), updatedAt: Date.now(), persona: persona.id, model: defaultModel }, ...s.conversations],
      currentConversationId: id,
    }))
  }

  return (
    <div style={{
      flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', padding: '2rem 1rem', overflow: 'auto',
    }}>
      {/* Logo */}
      <div style={{
        width: 64, height: 64, borderRadius: '50%', background: 'var(--accent)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: '1.75rem', color: 'white', fontWeight: 800, marginBottom: '1.25rem',
      }}>K</div>

      <h1 style={{ fontSize: '1.75rem', fontWeight: 700, marginBottom: '0.4rem', textAlign: 'center' }}>
        Kii Chat
      </h1>
      <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginBottom: '2rem', textAlign: 'center', maxWidth: 400 }}>
        Your personal AI assistant. Powered by OpenRouter — access hundreds of models from one place.
      </p>

      {/* Features */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
        gap: '0.75rem', width: '100%', maxWidth: 520, marginBottom: '2rem',
      }}>
        {[
          { icon: <Zap size={18} />, title: 'Multi-model', desc: 'Switch between Claude, GPT, Gemini and more' },
          { icon: <Monitor size={18} />, title: 'App Builder', desc: 'Preview React apps built by AI in real time' },
          { icon: <Download size={18} />, title: 'File export', desc: 'Download code with the model name as filename' },
        ].map((f, i) => (
          <div key={i} style={{
            padding: '0.9rem', background: 'var(--bg-secondary)', border: '1px solid var(--border)',
            borderRadius: 10, display: 'flex', flexDirection: 'column', gap: '0.35rem',
          }}>
            <div style={{ color: 'var(--accent)' }}>{f.icon}</div>
            <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{f.title}</div>
            <div style={{ color: 'var(--text-muted)', fontSize: '0.78rem' }}>{f.desc}</div>
          </div>
        ))}
      </div>

      {/* CTA */}
      {!hasKey ? (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.75rem', width: '100%', maxWidth: 320 }}>
          <button
            onClick={onOpenSettings}
            style={{
              width: '100%', padding: '0.75rem', borderRadius: 10, border: 'none',
              background: 'var(--accent)', color: 'white', cursor: 'pointer',
              fontWeight: 600, fontSize: '0.95rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem',
            }}
          >
            <Key size={17} /> Set API Key
          </button>
          <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', textAlign: 'center' }}>
            Free at <a href="https://openrouter.ai/keys" target="_blank" rel="noopener" style={{ color: 'var(--accent)' }}>openrouter.ai/keys</a> · Stored locally
          </p>
        </div>
      ) : (
        <button
          onClick={startChat}
          style={{
            padding: '0.75rem 2rem', borderRadius: 10, border: 'none',
            background: 'var(--accent)', color: 'white', cursor: 'pointer',
            fontWeight: 600, fontSize: '0.95rem',
          }}
        >
          Start chatting
        </button>
      )}
    </div>
  )
}
