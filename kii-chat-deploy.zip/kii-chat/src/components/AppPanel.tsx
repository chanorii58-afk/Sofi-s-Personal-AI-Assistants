'use client'

import { useState, useMemo } from 'react'
import { useStore } from '@/store'
import { ChevronLeft, ChevronRight, X, Code, Monitor } from 'lucide-react'

interface AppPanelProps {
  onClose: () => void
}

function wrapInHtml(code: string, modelId: string): string {
  // If it's already HTML
  if (code.trim().startsWith('<') && (code.includes('<html') || code.includes('<!DOCTYPE') || code.includes('<div'))) {
    return code
  }

  // React/JSX: wrap in a simple renderer using CDN
  const isReact = code.includes('import React') || code.includes('useState') ||
    code.includes('export default') || code.includes('const App')

  if (isReact) {
    // Strip import statements and export default for inline use
    let cleaned = code
      .replace(/^import\s+.*?from\s+['"][^'"]+['"]\s*;?\s*$/gm, '')
      .replace(/^export\s+default\s+/gm, '')
      .trim()

    return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App - ${modelId}</title>
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>
    * { box-sizing: border-box; }
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    const { useState, useEffect, useRef, useCallback, useMemo } = React;
    ${cleaned}
    const ComponentToRender = typeof App !== 'undefined' ? App : 
      (typeof default_1 !== 'undefined' ? default_1 : () => <div>Component loaded</div>);
    ReactDOM.createRoot(document.getElementById('root')).render(<ComponentToRender />);
  </script>
</body>
</html>`
  }

  // Plain JS
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App - ${modelId}</title>
  <style>* { box-sizing: border-box; } body { margin: 0; font-family: sans-serif; }</style>
</head>
<body>
  <script>${code}</script>
</body>
</html>`
}

function getModelSlug(model: string): string {
  return model.split('/').pop()?.replace(/[^a-zA-Z0-9_-]/g, '-') || model
}

export function AppPanel({ onClose }: AppPanelProps) {
  const { appPages } = useStore()
  const [viewSource, setViewSource] = useState(false)

  const modelIds = Object.keys(appPages)
  const [pageIndex, setPageIndex] = useState(0)

  const currentModelId = modelIds[pageIndex] || ''
  const currentCode = appPages[currentModelId] || ''
  const htmlContent = useMemo(() => currentCode ? wrapInHtml(currentCode, currentModelId) : '', [currentCode, currentModelId])

  if (modelIds.length === 0) {
    return (
      <div className="app-panel-enter" style={{
        width: '100%', height: '100%',
        display: 'flex', flexDirection: 'column',
        background: 'var(--bg-secondary)', borderLeft: '1px solid var(--border)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0.75rem 1rem', borderBottom: '1px solid var(--border)' }}>
          <span style={{ fontWeight: 600, fontSize: '0.9rem' }}>App Preview</span>
          <button onClick={onClose} style={{ padding: '0.2rem', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer' }}>
            <X size={16} />
          </button>
        </div>
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', color: 'var(--text-muted)', fontSize: '0.875rem', padding: '2rem' }}>
          <Monitor size={36} style={{ opacity: 0.3 }} />
          <p style={{ textAlign: 'center', margin: 0 }}>
            No apps yet. Ask a model to build you a React app, then click the <strong style={{ color: 'var(--accent)' }}>▶ App</strong> button on any code block.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="app-panel-enter" style={{
      width: '100%', height: '100%',
      display: 'flex', flexDirection: 'column',
      background: 'var(--bg-secondary)', borderLeft: '1px solid var(--border)',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: '0.5rem',
        padding: '0.6rem 0.75rem', borderBottom: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        {/* Navigation */}
        <button
          onClick={() => setPageIndex(i => Math.max(0, i - 1))}
          disabled={pageIndex === 0}
          style={{
            padding: '0.25rem', border: 'none', background: 'transparent',
            color: pageIndex === 0 ? 'var(--text-muted)' : 'var(--text-secondary)',
            cursor: pageIndex === 0 ? 'not-allowed' : 'pointer', borderRadius: 4,
          }}
        >
          <ChevronLeft size={16} />
        </button>

        <div style={{ flex: 1, overflow: 'hidden' }}>
          <div style={{ fontSize: '0.8rem', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'var(--accent)' }}>
            {getModelSlug(currentModelId)}
          </div>
          <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>
            {pageIndex + 1} of {modelIds.length}
          </div>
        </div>

        <button
          onClick={() => setPageIndex(i => Math.min(modelIds.length - 1, i + 1))}
          disabled={pageIndex === modelIds.length - 1}
          style={{
            padding: '0.25rem', border: 'none', background: 'transparent',
            color: pageIndex === modelIds.length - 1 ? 'var(--text-muted)' : 'var(--text-secondary)',
            cursor: pageIndex === modelIds.length - 1 ? 'not-allowed' : 'pointer', borderRadius: 4,
          }}
        >
          <ChevronRight size={16} />
        </button>

        <div style={{ width: '1px', height: 16, background: 'var(--border)', margin: '0 0.25rem' }} />

        <button
          onClick={() => setViewSource(!viewSource)}
          title="Toggle source"
          style={{
            padding: '0.25rem 0.5rem', borderRadius: 4, border: '1px solid var(--border)',
            background: viewSource ? 'var(--accent-bg)' : 'transparent',
            color: viewSource ? 'var(--accent)' : 'var(--text-muted)',
            cursor: 'pointer', fontSize: '0.72rem',
          }}
        >
          <Code size={13} />
        </button>

        <button onClick={onClose} style={{ padding: '0.25rem', border: 'none', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', borderRadius: 4 }}>
          <X size={15} />
        </button>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        {viewSource ? (
          <pre style={{
            margin: 0, padding: '0.75rem', height: '100%', overflow: 'auto',
            background: '#1a1a2e', color: '#cdd6f4', fontSize: '0.8rem',
            fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-all',
          }}>
            {currentCode}
          </pre>
        ) : (
          <iframe
            key={currentModelId + pageIndex}
            srcDoc={htmlContent}
            sandbox="allow-scripts allow-same-origin"
            style={{ width: '100%', height: '100%', border: 'none' }}
            title={`App: ${getModelSlug(currentModelId)}`}
          />
        )}
      </div>

      {/* Model dots */}
      {modelIds.length > 1 && (
        <div style={{
          display: 'flex', justifyContent: 'center', gap: '0.3rem',
          padding: '0.5rem', borderTop: '1px solid var(--border)', flexShrink: 0,
        }}>
          {modelIds.map((_, i) => (
            <button
              key={i}
              onClick={() => setPageIndex(i)}
              style={{
                width: 6, height: 6, borderRadius: '50%', border: 'none', cursor: 'pointer',
                background: i === pageIndex ? 'var(--accent)' : 'var(--border)',
                padding: 0, transition: 'background 0.15s',
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}
