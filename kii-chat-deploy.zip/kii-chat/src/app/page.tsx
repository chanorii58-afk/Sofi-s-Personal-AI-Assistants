'use client'

import { useEffect, useState } from 'react'
import { Sidebar } from '@/components/Sidebar'
import { ChatArea } from '@/components/ChatArea'
import { SettingsModal } from '@/components/SettingsModal'
import { WelcomeScreen } from '@/components/WelcomeScreen'
import { useStore } from '@/store'
import { useApiAutoDetect } from '@/hooks/useApiAutoDetect'

export default function Home() {
  const {
    currentConversation, showSettings, setShowSettings,
    apiKey, ultraplinianApiUrl, ultraplinianApiKey, isHydrated,
  } = useStore()

  const [sidebarOpen, setSidebarOpen] = useState(true)

  useApiAutoDetect()

  const proxyMode = !apiKey && !!ultraplinianApiUrl && !!ultraplinianApiKey

  if (!isHydrated) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: 'var(--bg-primary)', color: 'var(--text-muted)', fontSize: '0.9rem',
      }}>
        Loading…
      </div>
    )
  }

  return (
    <main style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: 'var(--bg-primary)', color: 'var(--text-primary)' }}>
      <Sidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(o => !o)} />

      <div style={{ flex: 1, display: 'flex', overflow: 'hidden', minWidth: 0 }}>
        {(!apiKey && !proxyMode) || !currentConversation ? (
          <WelcomeScreen onOpenSettings={() => setShowSettings(true)} />
        ) : (
          <ChatArea onSidebarToggle={() => setSidebarOpen(o => !o)} />
        )}
      </div>

      {showSettings && <SettingsModal onClose={() => setShowSettings(false)} />}
    </main>
  )
}
